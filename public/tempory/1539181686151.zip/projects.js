/**
 * author yaojun
 * date: 2016/5/31.
 * function: 工程接口
 */

var express = require('express');
var router = express.Router();
var projectService = require('./../service/projects');
var messageService = require('./../service/messages');

var proToUserService = require('./../service/proToUser');
var prologService = require('./../service/prolog');
var taskService = require('./../service/task');
var attService = require('./../service/attachment');
var chargeService = require('./../service/charge')
var proMaterialService = require('./../service/proMaterials');

var Filter = require('../service/filter');
var uploads = require('./../service/uploadTool');

var selectConfig = require('../src/services/select-config');
var Filter = require('../service/filter');

var proCaculateService = require('./../service/proCaculate');
var proRatioService = require('./../service/proRatio');
var proTransportRatioService = require('./../service/proTransportRatio');
var proChildOldService = require('./../service/proChildOld');

var proChildService = require('../service/proChild');
var proOtherFeeService = require('../service/proOtherFee');

var budgetMagic = require('../service/budget');

var price = require('../src/services/price-config').data;
var collarMaterialService = require('../service/collarMaterial');
var backMaterialService = require('../service/backMaterial');

var protmpService = require('./../service/protmp');
var protmphelper = require('../service/protmphelper')


var proEndService = require('../service/proEnd');

var messageSendService = require('../service/messageSend');


var access = require('../service/access');
/*
 * JSON接口权限过滤
 */
 /*
router.all('/*', function(req, res, next){

    if(req.session.user){
        next();
    } else {
        res.json({
            code: -1,
            msg: '没有权限'
        });
    }
});
*/


/*添加一个新工程的接口*/
router.post('/insertProjects',function(req,res,next){
    var path = req.body.filepath;
    var name = req.body.filename;
    delete req.body.filepath;
    delete req.body.filename;

    req.body.proCreateDate = new Date().getTime()/1000;  //默认插入时间
    req.body.preUserId = req.session.user.userId;
    req.body.proName = '新建工程';

    //如果是就工程管理员
    if(req.session.user.userId ==33){
      req.body.proLevelOne = 33;
    }

    projectService.insertProjects(req.body,function(lastProjectId){

        proToUserService.insertProToUser({userId:req.session.user.userId,proId:lastProjectId},function(result){
            var reg = /^\s*$/;
            if(typeof path != 'undefined' && !reg.test(path)){
                attService.add({
                    proId: lastProjectId,
                    attUrl: path,
                    attName: name,
                    attType: 1
                }, function(d){
                    res.json(d)
                })
            } else {
                res.json(result);
            }
        });
    });
});

/*编辑一个工程的接口*/
router.post('/edit',function(req,res,next){
    req.body.preUserId = req.session.user.userId;
    projectService.editProjects(req.body,function(result){
        res.json(result);
    });
});

//删除工程
router.get('/delete', function(req, res, next){
    projectService.deleteProject(req.query, function(result){
        res.json(result);
    })
})

/*得到全部工程*/
router.get('/getProjects',function(req,res,next){

  if(req.session.user.userType == 44){
      projectService.getProjectsWareBitch2(req.query,function(result){
          res.json(result);
      });
  } else {
    projectService.getProjects(req.query,function(result){
        res.json(result);
    });
  }



});

router.get('/getProjectsWare',function(req,res,next){

  projectService.getProjectsWareBitch(req.query, function(result){
      res.json(result);
  });

});

/**
 * @category 得到一个用户的全部工程
 */

router.get('/getSelfAllProjects',function(req,res,next){

    req.query.userId = req.session.user.userId;
    projectService.getSelfAllProjects(req.query,function(result){

        res.json({code:1,data:result});
    });
});


/**
 * @category 得到自己全部工程的数量，用于分页
 */
router.get('/getSelfAllProjectsCount',function(req,res,next){

    req.query.uerId = req.session.user.userId;

    projectService.getSelfAllProjectsCount(req.query,function(result){
            res.json({code:1,data:result});
    });
});

/**
 * @category 得到用户自己待处理的工程
 */
router.get('/getSelfProjects',function(req,res,next){
    req.query.userId = req.session.user.userId;
    req.query.userType = req.session.user.userType;

    /*
     * 如果是财务，获取归档前的所有工程，否则只显示自己流程下的
     */
    if(req.session.user.userType == 25){
        projectService.getProjectsPart(req.query, 24, 99,function(result){
            res.json({
                code: 1,
                data: result
            });
        });
    } else {
        projectService.getSelfProjects(req.query,function(result){
            res.json({
                code: 1,
                data: result
            });
        });
    }

});

/**
 * @category 得到用户自己退回的工程
 */
router.get('/getSelfBackProjects',function(req,res,next){
    req.query.userId = req.session.user.userId;
    req.query.userType = req.session.user.userType;
    projectService.getSelfBackProjects(req.query,function(result){
        res.json({
            code: 1,
            data: result
        });
    });
});

/**
 * @category 得到用户自己的全部工程
 */
router.get('/getSelfAllProjects',function(req,res,next){
    req.query.userId = req.session.user.userId;
    req.query.userType = req.session.user.userType;



    projectService.getSelfAllProjects(req.query,function(result){
        res.json({
            code: 1,
            data: result
        });
    });
});


/*删除一个工程*/
router.get('/deleteProjects',function(req,res,next){

    projectService.deleteProject(req.query,function(result){
        res.json(result);
    });

});

/*上传工程附件*/
router.post('/uploadFile',function(req,res,next){

    uploads(req).done(function(data){
        //console.log("返回的路径为:"+data);
        res.jsonp(data);
    });

});



/*
 * 主分支工程流转接口
 * 将工程流转到下个人(或多个人)目前支持一个人
 * @param nextUser
 * @param nextuser2
 * @param proId
 * @param proLevelOne
 * @param proLevelTwo
 * @param logContent
 */
router.post('/goNext', function(req, res, next){
    var prolog = {
        proId: req.body.proId,
        logContent: req.body.logContent,
        userId: req.body.nextUser,
        userName: req.session.user.userName,
        logNote: selectConfig.userType[req.session.user.userType].text + ' 流转到 ' + selectConfig.userType[req.body.userType].text
    };

    var proToUser = {
        proId: req.body.proId,
        userId: req.body.nextUser
    };

    var userName = req.session.user.userName;
    var logContent = req.body.logContent;
    var messageContent = '您有新的待处理工程，来自 '+userName
                +' ('+selectConfig.userType[req.session.user.userType].text+' ):'
                + logContent + ', 请及时处理，以免耽误工程进度。';



    var projects = {
        proId: req.body.proId,
        preUserId: req.session.user.userId,
        //proLevelOne: req.body.proLevelOne,
        //proLevelTwo: 0,
        //proLevelThree: 0,
        editDate: new Date().getTime()/1000,
        handleStatus: 0,
        handleContent: '通过'
    };



    if(req.body.proLevelOne){
        if(req.body.proLevelOne == 0 || req.body.proLevelOne == ''){
            res.json({
                code: 0,
                msg: '错误的流程号'
            })
        }
        projects.proLevelOne = req.body.proLevelOne;
    }

    if(req.body.proLevelTwo){
        projects.proLevelTwo = req.body.proLevelTwo;
    }

    if(req.body.proLevelThree){
        projects.proLevelThree = req.body.proLevelThree;
    }

    if(req.body.proBranchState){
        projects.proBranchState = req.body.proBranchState;
    }


    //如果是USERTYPE=2，并且TASK没有填写
    if(req.session.user.userType == 2){
        taskService.getById(req.body.proId, function(result){

            if(result.length > 0){
                go();
            } else {
                res.json({
                    code: 0,
                    msg: '您还没有增加任务单'
                });
            }
        })
    } else {
      go();
      //如果是工程预算
      if(req.session.user.userType == 8){
          //cover.compilePerson = req.session.user.userName;
          //goPreivew();
      }

      //如果是预算审核
      else if(req.session.user.userType == 11){
          //cover.auditPerson = req.session.user.userName;
          //goPreivew();
      }

      //如果是预算复核
      else if(req.session.user.userType == 12){
          //cover.recheckPerson = req.session.user.userName;
          //goPreivew();
      }

      else {
        //go();
      }

    }



    function goPreivew(){
      var cover = {
        proId: req.body.proId
      }
      budgetCoverService.add(cover,function(result){
        cover.id = result.lastId;
        budgetCoverService.update(cover,function(result){
            //res.json(result);
            go();
        })
      })
    }





    function go(){
        proToUserService.insertProToUser(proToUser,function(ptres){
            prologService.add(prolog, function(prores){
                projectService.editProjects(projects, function(data){
                    messageSendService.addNext({
                      userId: req.body.nextUser,
                      userType: req.body.userType,
                      proId: req.body.proId,
                      isWarehouse: 0
                    }, function(message){
                      /*系统发送留言*/
                      messageService.insertMessages({
                          receiverId:req.body.nextUser,
                          msgContent:messageContent,
                          msgTitle: "您有新的待处理工程",
                          proId: req.body.proId
                      },function(data){
                          //console.log(data);
                          res.json({
                              code:1,
                              msg: '工程流转成功，等待对方处理'
                          })
                      });
                    })



                })
            })
        });
    }

});

/*
 * 分支工程流转接口
 * 将工程流转某个人
 * @param nextUser
 * @param nextuser2
 * @param proId
 * @param proLevelOne
 * @param proLevelTwo
 * @param proLevelThree
 * @param logContent
 */
router.post('/goTo', function(req, res, next){
  if(typeof req.body.nextUser == 'undefined'){
    req.body.nextUser = req.session.user.userId;
  }

    var prolog = {
        proId: req.body.proId,
        logContent: req.body.logContent,
        userId: req.body.nextUser,
        userName: req.session.user.userName,
        logNote: selectConfig.userType[req.session.user.userType].text + ' 流转到 ' + selectConfig.userType[req.body.userType].text
    };

    var proToUser = {
        proId: req.body.proId,
        userId: req.body.nextUser
    };

    var userName = req.session.user.userName;
    var logContent = req.body.logContent;
    var messageContent = '您有新的待处理工程，来自 '+userName
                +' ('+selectConfig.userType[req.session.user.userType].text+' ):'
                + logContent + ', 请及时处理，以免耽误工程进度。';


    var projects = {
        proId: req.body.proId,
        preUserId: req.session.user.userId,
        handleStatus: 0,
        editDate: new Date().getTime()/1000,
        handleContent: '通过'
    };

    if(req.body.proLevelOne){
        if(req.body.proLevelOne == 0 || req.body.proLevelOne == ''){
            res.json({
                code: 0,
                msg: '错误的流程号'
            })
        }
        projects.proLevelOne = req.body.proLevelOne;
    }

    if(req.body.proLevelTwo){
        projects.proLevelTwo = req.body.proLevelTwo;
    }

    if(req.body.proLevelThree){
        projects.proLevelThree = req.body.proLevelThree;
    }

    if(req.body.proBranchState){
        projects.proBranchState = req.body.proBranchState;
    }

    /*
     * 如果是施工队申请增料单，则计算第几张增料单，并存入proMaterFormCount来标示
     */
    if((req.session.user.userType==19 || req.session.user.userType==5 ) && req.body.proLevelTwo == 5){
      console.log('1111111')
        proMaterialService.selectMaxType({
            proId: req.body.proId
        }, function(max){
            projects.proMaterFormCount = max.data + 1;
            console.log(projects)
            go()
        })
    } else {
        console.log('2222222222222')
        go ();
    }





    function go(){
        proToUserService.insertProToUser(proToUser,function(ptres){
            prologService.add(prolog, function(prores){
                projectService.editProjects(projects, function(data){

                  messageSendService.addNext({
                    userId: req.body.nextUser,
                    userType: req.body.userType,
                    proId: req.body.proId,
                    isWarehouse: 0
                  }, function(message){
                    /*系统发送留言*/
                    messageService.insertMessages({
                        receiverId:req.body.nextUser,
                        msgContent:messageContent,
                        msgTitle: "您有新的待处理工程",
                        proId: req.body.proId
                    },function(data){
                        //console.log(data);
                        res.json({
                            code:1,
                            msg: '工程流转成功，等待对方处理'
                        })
                    });
                  })


                })
            })
        });
    }

});

/*
 * 主分支工程退回接口
 * 将工程流退回
 * @param proId
 * @param proLevelOne
 * @param proLevelTwo
 * @param logContent
 */
router.post('/goBack', function(req, res, next){


    var prolog = {
        proId: req.body.proId,
        logContent: req.body.logContent,
        userId: req.session.user.userId,
        userName: req.session.user.userName,
        logNote: selectConfig.userType[req.session.user.userType].text + ' 退回到 ' + selectConfig.userType[req.body.userType].text
    };

    var projects = {
        proId: req.body.proId,
        proLevelOne: req.body.proLevelOne,
        proLevelTwo: 0,
        handleStatus: 1,
        editDate: new Date().getTime()/1000,
        handleContent: req.body.logContent||'对方未填写留言'
    };

    if(req.body.proLevelOne){
        if(req.body.proLevelOne == 0 || req.body.proLevelOne == ''){
            res.json({
                code: 0,
                msg: '错误的流程号'
            })
        }
        projects.proLevelOne = req.body.proLevelOne;
    }

    if(req.body.proLevelTwo){
        projects.proLevelTwo = req.body.proLevelTwo;
    }

    if(req.body.proLevelThree){
        projects.proLevelThree = req.body.proLevelThree;
    }

    if(req.body.proBranchState){
        projects.proBranchState = req.body.proBranchState;
    }

    //prologService.add(prolog, function(prores){
        projectService.editProjects(projects, function(data){

          messageSendService.addBack({
            userType: req.body.userType,
            proId: req.body.proId,
            isWarehouse: 0
          }, function(message){
            /*系统发送留言*/
            messageService.insertMessages({
                receiverId:message.data[0].userId,
                msgContent:"您有新的退回工程，请进入退回工程查看处理",
                msgTitle: "您有新的退回工程",
                proId: req.body.proId
            },function(data){
                //console.log(data);
                //proToUserService.del(prolog, function(){})
                prolog.userId = message.data[0].userId;



                prologService.add(prolog, function(prores){
                  res.json({
                      code:1,
                      msg: '工程退回成功，等待对方处理'
                  })
                })



            });
          })


        })
    //});
});

/*
 * 将工程流转到某个位置
 * @param aimUser
 * @param aimUser2
 * @param proId
 * @param proLevelOne
 * @param proLevelTwo
 * @param logContent
 * @param logNote
 */
router.post('/goTo', function(req, res, next){
    var prolog = {
        proId: req.body.proId,
        logContent: req.body.logContent,
        userId: req.body.aimUser,
        userName: req.session.user.userName,
        logNote: req.body.logNote
    };

    var proToUser = {
        proId: req.body.proId,
        userId: req.body.aimUser
    };

    var userName = req.session.user.userName;
    var logContent = req.body.logContent;
    var messageContent = '您有新的待处理工程，来自 '+userName
                +' ('+selectConfig.userType[req.session.user.userType].text+' ):'
                + logContent + ', 请及时处理，以免耽误工程进度。';


    //计算下个level,需要进一步完善逻辑
    var levelone = parseInt(req.body.proLevelOne)+1;

    var projects = {
        proId: req.body.proId,
        preUserId: req.session.user.userId,
        proLevelOne: levelone,
        proLevelTwo: 0,
        handleStatus: 0,
        editDate: new Date().getTime()/1000,
        handleContent: '通过'
    };


    //如果是USERTYPE=2，并且TASK没有填写
    if(req.session.user.userType == 2){
        taskService.getById(req.body.proId, function(result){

            if(result.length > 0){
                go();
            } else {
                res.json({
                    code: 0,
                    msg: '您还没有增加任务单'
                });
            }
        })
    } else {
        go ();
    }

    function go(){
        proToUserService.insertProToUser(proToUser,function(ptres){
            prologService.add(prolog, function(prores){
                projectService.editProjects(projects, function(data){

                  messageSendService.addNext({
                    userId: req.body.nextUser,
                    userType: req.body.userType,
                    proId: req.body.proId,
                    isWarehouse: 0
                  }, function(message){
                    /*系统发送留言*/
                    messageService.insertMessages({
                        receiverId:req.body.nextUser,
                        msgContent:messageContent,
                        msgTitle: "您有新的待处理工程",
                        proId: req.body.proId
                    },function(data){
                        //console.log(data);
                        res.json({
                            code:1,
                            msg: '工程流转成功，等待对方处理'
                        })
                    });
                  })


                })
            })
        });
    }

});

/*
 * 更改流程状态，不改变其他标志位
 * 用于终止工程
 * @param proId
 * @param proLevelOne
 * @param proLevelTwo
 * @param logContent
 */
router.post('/goOnly', function(req, res, next){

var proToUser = {
        proId: req.body.proId,
        userId: req.body.nextUser
    };

    var prolog = {
        proId: req.body.proId,
        logContent: req.body.logContent,
        userId: req.session.user.userId,
        userName: req.session.user.userName,
        logNote: selectConfig.userType[req.session.user.userType].text + ' 申请终止工程 '// + selectConfig.userType[req.session.user.userType-1].text
    };

    var projects = {
        proId: req.body.proId,
        editDate: new Date().getTime()/1000,
        //handleStatus: 1,
        stopReason: req.body.logNote||'对方未填写原因'
    };

    if(req.body.proLevelOne){
        if(req.body.proLevelOne == 0 || req.body.proLevelOne == ''){
            res.json({
                code: 0,
                msg: '错误的流程号'
            })
        }
        projects.proLevelOne = req.body.proLevelOne;
    }

    if(req.body.proLevelOne){
        projects.proLevelOne = req.body.proLevelOne;
    }

    if(req.body.proLevelTwo){
        projects.proLevelTwo = req.body.proLevelTwo;
    }

    if(req.body.proLevelThree){
        projects.proLevelThree = req.body.proLevelThree;
    }

    if(req.body.proBranchState){
        projects.proBranchState = req.body.proBranchState;
    }

    /*
    prologService.add(prolog, function(prores){
        projectService.editProjects(projects, function(data){

            res.json({
                code:1,
                msg: '成功，等待对方处理'
            })
        })
    });
    */
    if(req.body.nextUser){
        go();
    } else {
        go2();
    }


    function go(){
        proToUserService.insertProToUser(proToUser,function(ptres){
            prologService.add(prolog, function(prores){
                projectService.editProjects(projects, function(data){
                    /*系统发送留言*/
                    messageService.insertMessages({
                        receiverId:req.body.nextUser,
                        msgContent:"有工程申请终止，请及时处理",
                        msgTitle: "有工程申请终止，请及时处理",
                        proId: req.body.proId
                    },function(data){
                        console.log(data);
                    });
                    res.json({
                        code:1,
                        msg: '成功，等待对方处理'
                    })
                })
            })
        });
    }

    function go2(){
        //proToUserService.insertProToUser(proToUser,function(ptres){
            prologService.add(prolog, function(prores){
                projectService.editProjects(projects, function(data){
                    /*系统发送留言*/

                    res.json({
                        code:1,
                        msg: '成功，等待对方处理'
                    })
                })
            })
       // });
    }
});

/*
 * 查询工程流转记录
 * @param proId
 */
router.get('/getLog', function(req, res, next){
    prologService.getByPro(req.query, function(d){
        res.json({
            code: 1,
            msg: "",
            data: d
        });
    })
});


/*****************************************
                工程任务单
******************************************/
/*
 * 添加新的工程任务单
 */
router.post('/task/add', function(req, res, next){
    //req.body.addTime = parseInt(new Date().getTime()/1000);
    taskService.add(req.body, function(d){
        res.json(d);
    })
});

/*
 * 编辑工程任务单
 */
router.post('/task/edit', function(req, res, next){
    taskService.editById(req.body, function(d){
        res.json(d);
    })
});


/**
 * 得到工程的编号 ，传入工程的名称
 */
router.get('/getProNumber',function(req,res,next){

    projectService.getProNumber(req.query,function(result){
        res.json(result);
    });
});

/*
 * 获取工程预算结果，传入proId
 */
router.get('/probudget', function(req, res, next){
    var proId = req.query.proId;
    var type = req.query.type||'preview';//预算还是决算,preview||final
    var pagetype = req.query.pagetype||'' //preview||final

    var forceupdate = req.query.forceupdate||false // 是否同步预决算封面
    if(!access.hasbudget(req.session.user.userType)){
      res.json({
        msg: '无权限'
      })
    }

    projectService.getById(req.query.proId, function(d){

        //读取定额系数
        proRatioService.getByProId(proId
        , function(ratio){


            //读取材料
            proMaterialService.getProMaterials({
                        pageIndex: 0,
                        pageSize: 9999,
                        proId: proId
                    }, function(materials){

                //读取工程子目
                proChildService.getByProId(proId, function(child){

                    proTransportRatioService.getDatas({
                        proId: proId
                    }, function(transport){
                        proChildOldService.getByProId(proId, function(old){
                            //读取费率表
                            proCaculateService.getDataByPages({
                                pageIndex: 0,
                                pageSize: 9999,
                                proId: proId
                            }, function(caculate){



                                //读取其他费用
                                proOtherFeeService.getByProId(proId, function(fee){
                                    var mode = 'preview';


                                   try{
                                     /*
                                      * 如果是决算则把暂列金额清零
                                      */
                                     if(req.session.user.userType >= 22 ){
                                         for(var kk in caculate.data){
                                             if(caculate.data[kk].caNumber == 35){
                                                 caculate.data[kk].caInstallUnitPrice = 0;
                                                 caculate.data[kk].caAmount = 0;
                                             }
                                         }
                                         var mode = 'final';
                                     }

                                      var magic = {};
                                        magic = budgetMagic.caculate(caculate.data,
                                            ratio,
                                            materials.data,
                                            child,
                                            fee.data,
                                            transport.data,
                                            old,
                                            price,
                                            mode)
                                        //console.log(magic.preview_money);

                                        if(type == 'final'){
                                          for(var key in magic.data){
                                            if(magic.data[key].caNumber==35)
                                            magic.data.splice(key,1)
                                          }
                                        }





                                        protmphelper(req, magic, 'budget', function(d){
                                          // 更新总价
                                          var updateData = {
                                              proId: proId
                                          }

                                          if(type == 'preview'){//如果是预算
                                              updateData['previewMoney'] = d.preview_money||0;
                                          } else {//否则是决算
                                              updateData['finalMoney'] = d.preview_money||0;
                                          }

                                          if(
                                            (req.session.user.userType == 8 )
                                            ||
                                            (req.session.user.userType == 8)
                                            ||
                                            (req.session.user.userType == 22 )
                                            ||
                                            (req.session.user.userType == 22 )

                                          ){
                                            projectService.editProjects(updateData,function(result){

                                                proEndService.updateByProId({
                                                    proId: proId,
                                                    machinePrice: d.machinePrice||0,
                                                    euipmentPrice: d.euipmentPrice||0,
                                                    otherPrice: d.otherPrice||0,
                                                    materialPrice: d.materialPrice||0
                                                }, function(){


                                                    //res.json(magic);
                                                })

                                            });
                                          }
                                          //更细总价结束
                                          res.json(d);
                                        }, pagetype)

                                        //res.json(magic);





                                    } catch (e){
                                        console.log(e);
                                        res.json({
                                            code: 0,
                                            msg: '计算失败，请检查表单是否完整'
                                        })
                                    }


                                })


                            })
                        })
                    })

                })
            })


        })
    })
});




/*
 * 模糊搜索工程
 */
router.get('/search', function(req, res, next){


  if(req.query.widthCollar){
    projectService.search(req.query,function(d){
      if(d.data.length == 0){
        res.json(d);
      } else {
        var n = 0;
        for(var key in d.data){
          (function(n){
            backMaterialService.getBackMaterialDatas({proId:req.query.proId}, function(collars){

              if(collars.data.length > 0){
                d.data[n].collar = true
              } else {
                d.data[n].collar = false
              }
              n++;
              if(n >= d.data.length){
                res.json(d);
              }

            })
          })(key)


        }
      }

    })
  } else {
    projectService.search(req.query,function(d){
        res.json(d);
    })
  }



});

/**
 * 模糊搜索自己的工程
 */
router.get('/searchSelf', function(req, res, next){

    req.query.userId=req.session.user.userId;

    projectService.searchSelf(req.query,function(d){
        res.json(d);
    })

});

/*
 * 终止工程
 */
router.get('/kill', function(req, res, next){
    projectService.editProjects({
        proId: req.query.proId,
        proLevelOne:1,
        proLevelTwo:1,
        proLevelThree:1,
        proBranchState:0,
        handleStatus:0
    }, function(code){
        res.json(code)
    })
})

//工程流程查询统计
router.get('/flowhistory', function(req, res, next){
  var param = {}

  if(req.query.proType && req.query.proType != -1){
    param.proType = req.query.proType
  }

  if(req.query.proNumber && req.query.proNumber != -1){
    param.proNumber = req.query.proNumber
  }

  if(req.query.proName && req.query.proName != -1){
    param.proName = req.query.proName
  }

  if(req.query.pageSize){
    param.pageSize = req.query.pageSize
  }

  if(req.query.pageIndex){
    param.pageIndex = req.query.pageIndex
  }

  if(req.query.pageIndex){
    param.pageIndex = req.query.pageIndex
  }

  if(req.query.st && req.query.st != 0){
    param.st = req.query.st
  }

  if(req.query.et && req.query.et != 0){
    param.et = req.query.et
  }


  param.userId = req.session.user.userId



  projectService.flowhistory(param, function(code){
    var projects = {}
    if(code.length > 0){
      for(var i=0; i<code.length; i++){
        if(projects[code[i].pid]){

          if(code[i].logTime && code[i].userType){
            projects[code[i].pid].log[code[i].userType] = {
              userType: code[i].userType,
              time: code[i].logTime
            }
          }

        } else {
          var p = code[i]
          p.log = {
            '2': {}, //业务受理岗位
            '4': {}, //设计签发发送
            '6': {},
            '7': {},
            '11': {},

          }

          if(code[i].logTime && code[i].userType){
              p.log[code[i].userType] ={
                userType: code[i].userType,
                time: code[i].logTime
              }
          }

          projects[p.pid] = p
        }
      }
    }

    console.log('projects:::::::')
    console.log(projects)

    var pppp = []

    for(var key in projects){
      pppp.push(projects[key])
    }

      res.json({
        code: 1,
        data: pppp
      })
  })
})

/**
 * 查询时间段内的完成预算工程
 */
router.get('/getPreviewByTime', function(req, res, next){
    projectService.getPreviewByTime({
        st: req.query.st,
        et: req.query.et
    }, function(code){
      //console.log(code)

      //res.json(code)
      var done = 0

      if(code.data.length == 0){
          res.json(code)
          return
      }

      for(var i=0; i<code.data.length; i++){
        code.data[i].log = []
        code.data[i].now = selectConfig.userType[code.data[i].proLevelOne].text;
        //code.data[i].lasttime = []
        var n = i;

        (function(n, code){
          prologService.getByPro({
            proId:code.data[n].proId
          }, function(log){
            done++
            console.log(log)
           code.data[n].log = log

           code.data[n].aa = ''
           code.data[n].bb = ''
           code.data[n].cc = ''

            for(var key in log){
              code.data[n].lasttime = log[0].logTime
              if(log[key].userType == 8){
                code.data[n].aa = log[key].uname
              }


              if(log[key].userType == 12){
                code.data[n].bb = log[key].unamee
              }

              if(log[key].userType == 12){
                code.data[n].cc = log[key].uname
              }
            }

            if(done == code.data.length){
                res.json(code)
            }

          })

        })(n, code)

      }

    })
})


/**
 *
 */
router.get('/getCharge', function(req, res, next){
    chargeService.getAllByPro(req.query, function(code){

      var projects = {}
      var d = []


      for(var key in code.data){
        if(projects[code.data[key].proId]){
          projects[code.data[key].proId].charge.push({
            chargeNature: code.data[key].chargeNature,
            chargeItem: code.data[key].chargeItem,
            chargeSum: code.data[key].chargeSum
          })

        } else {
          projects[code.data[key].proId] = {
            proId: code.data[key].proId,
            proName: code.data[key].proName,
            proNumber: code.data[key].proNumber,
            charge: [

            ]
          }

          projects[code.data[key].proId].charge.push({
            chargeNature: code.data[key].chargeNature,
            chargeItem: code.data[key].chargeItem,
            chargeSum: code.data[key].chargeSum
          })

        }
      }


      /**
  		 * src payment.js 存在相同代码
  		 */

    //  var data = []

      for(var n in projects){
        var total = 0;//
    		var revDesign = 0;
    		var backDesign = 0;
    		var backdoneDesign = 0;

    		var revEquip = 0;
    		var backEquip = 0;
    		var backdoneEquip = 0;

    		var revInstall = 0;
    		var backInstall = 0;
    		var backdoneInstall = 0;
        var data = projects[n].charge
  		for(var i=0; i<data.length; i++){
        if(data[i].chargeNature == 3){
          	total -= parseFloat(data[i].chargeSum);
        } else {
          	total += parseFloat(data[i].chargeSum);
        }

  			if(data[i].chargeNature == 0){
  				//预付款
  				if(data[i].chargeItem == 0){
  					//安装费
  					revInstall += parseFloat(data[i].chargeSum)
  				}
  				if(data[i].chargeItem == 1){
  					//设计费
  					revDesign += parseFloat(data[i].chargeSum)
  				}
  				if(data[i].chargeItem == 2){
  					//设备费
  					revEquip += parseFloat(data[i].chargeSum)
  				}
  			}

  			if(data[i].chargeNature == 1){
  				//进度款
  				if(data[i].chargeItem == 0){
  					//安装费
  					revInstall += parseFloat(data[i].chargeSum)
  				}
  				if(data[i].chargeItem == 1){
  					//设计费
  					revDesign += parseFloat(data[i].chargeSum)
  				}
  				if(data[i].chargeItem == 2){
  					//设备费
  					revEquip += parseFloat(data[i].chargeSum)
  				}
  			}

  			if(data[i].chargeNature == 2){
  				//结算款
  				if(data[i].chargeItem == 0){
  					//安装费
  					revInstall += parseFloat(data[i].chargeSum)
  				}
  				if(data[i].chargeItem == 1){
  					//设计费
  					revDesign += parseFloat(data[i].chargeSum)
  				}
  				if(data[i].chargeItem == 2){
  					//设备费
  					revEquip += parseFloat(data[i].chargeSum)
  				}
  			}

  			if(data[i].chargeNature == 3){
  				//退款
  				if(data[i].chargeItem == 0){
  					//安装费
  					backdoneInstall += parseFloat(data[i].chargeSum)
  				}
  				if(data[i].chargeItem == 1){
  					//设计费
  					backdoneDesign += parseFloat(data[i].chargeSum)
  				}
  				if(data[i].chargeItem == 2){
  					//设备费
  					backdoneEquip += parseFloat(data[i].chargeSum)
  				}
  			}

  		} // end for

      projects[n].total = total;
      projects[n].revDesign = revDesign;
      projects[n].backDesign = backDesign;
      projects[n].backdoneDesign = backdoneDesign;

      projects[n].revEquip = revEquip;
      projects[n].backEquip = backEquip;
      projects[n].backdoneEquip = backdoneEquip;

      projects[n].revInstall = revInstall;
      projects[n].backInstall = backInstall;
      projects[n].backdoneInstall = backdoneInstall;


    } // end for2


    var shit = []


    for(var key in projects){
      shit.push(projects[key])
    }




        res.json({
          code: 1,
          data: shit
        })
    })
})

module.exports = router;
